

%% *****************************************************************
clear all;
close all;
clc;
cd('F:\SZU and HKU\EEG data\N-back paragdim\PSI_Project')
%% 1 After the PSI calculating and the two-sample t test, one-sample t test should be implemented
% Input is either Depression or Healhty
Channle_number = 64;
subject_Dnum = 2; %% the amount of depressed subjects
two_One_sample_ttest('Amount_subject', subject_Dnum, 'AllNum_Channle', Channle_number, 'Group_type', 'Depression');  %% Depression and Healthy group 
cd('../')
subject_Hnum = 3; %% the amount of healthy subjects
two_One_sample_ttest('Amount_subject', subject_Hnum, 'AllNum_Channle', Channle_number, 'Group_type', 'Healthy');  %% Depression and Healthy group 

%% 2 Drawing the result of one-sample t test and the brain connections
% Input is either Depression or Healhty

select_mode = 'Increase';  % Increase or Decrease
cd('../')
flag_draw = three1_plot_oneTtest_Result('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Depression');  %% Depression and Healthy group 
cd('../')
flag_draw = three1_plot_oneTtest_Result('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Healthy');  %% Depression and Healthy group 
select_mode = 'Decrease';  % Increase or Decrease
cd('../')
flag_draw = three1_plot_oneTtest_Result('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Depression');  %% Depression and Healthy group 
cd('../')
flag_draw = three1_plot_oneTtest_Result('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Healthy');  %% Depression and Healthy group 

%% 3 Comparing the Drawing the result of one-sample t test and the brain connections
% Input is either Depression or Healhty
cd('../')
four1_S10_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Group_type', 'Depression', 'Amount_subject', subject_num);
cd('../')
four1_S30_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Group_type', 'Depression', 'Amount_subject', subject_num);
cd('../')
four2_DH_S10_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Group_type', 'Healthy', 'Amount_subject', subject_num);
cd('../')
four2_DH_S30_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Group_type', 'Healthy', 'Amount_subject', subject_num);

%% 4 Drawing the figure to display the (Mode selecting)
%%%%��������  1 average level
%%%%��������  0 whole level
cd('../')
select_mode = 0; 
four3_DH_S10_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Amount_subject', subject_num);
four3_DH_S30_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Amount_subject', subject_num);
select_mode = 1; 
four3_DH_S10_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Amount_subject', subject_num);
four3_DH_S30_sigPSI_Ttest('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Amount_subject', subject_num);

%% 5 Computing the correlation coefficent to evaluate the 
%%%%��������  1 average level
%%%%��������  0 whole level
significant_level = 'Strong';  %%  Significant 0.05; Strong 0.01; Serious 0.001;
select_mode = 'Increase'; 
five1_combin_the_sigPSI('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Depression', 'Amount_subject', subject_num);
cd('../')
five3_R_ttest1( 'Amount_subject', subject_num, 'AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Depression', 'Significant_level', significant_level);
cd('../')
five1_combin_the_sigPSI('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Healthy', 'Amount_subject', subject_num);
cd('../')
five3_R_ttest1( 'Amount_subject', subject_num, 'AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Healthy', 'Significant_level', significant_level);
cd('../')

select_mode = 'Decrease'; 
five1_combin_the_sigPSI('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Depression', 'Amount_subject', subject_num);
cd('../')
five3_R_ttest1('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Depression', 'Significant_level', significant_level);
cd('../')
five1_combin_the_sigPSI('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Healthy', 'Amount_subject', subject_num);
cd('../')
five3_R_ttest1('AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Healthy', 'Significant_level', significant_level);
cd('../')


%% *****************************************************************
%% 6 Drawing and comparing the brain connections
Hz_sig  =  9; %% ghe significant ferquency component you want to draw
plot_complete = three2_plot_Pair('Amount_subject', subject_num, 'AllNum_Channle', Channle_number, 'Mode_select', select_mode, 'Group_type', 'Depression', 'freq_domain', Hz_sig, 'Significant_level', significant_level);


