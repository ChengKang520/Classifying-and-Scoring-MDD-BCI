
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the functin of this script��
%           DH_S10_sigPSI_Ttest.m
%           The significant defference between Depression and Healhy.
%           According to every frequency domain, I used two-sample t test
%           to test the significant level of significant pairs' PSI (average
%           level and whole level)

% kangkangsome@gmail.com
% Kang Cheng, 2019/07/18
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function four3_DH_S30_sigPSI_Ttest(varargin)

nargs = length(varargin);
if nargs > 2
    if ~(round(nargs/2) == nargs/2)
        %    error('Odd number of input arguments??')
    end
    for i = 1:2:length(varargin)
        Param = varargin{i};
        Value = varargin{i+1};
        if ~isstr(Param)
            error('Flag arguments must be strings')
        end

        switch Param
            case 'AllNum_Channle'
                N_ch = Value;
            case 'Amount_subject'
                subject_num = Value;
            case 'Mode_select'
                select = Value;
            otherwise
                error(['Unknown input parameter ''' Param ''' ???'])
        end
    end
end

freq_length = 30;
b = 1:freq_length;

%%  compute the sigificant level (average and whole level)

S30_S10_T=zeros(freq_length,2);S10_S10_T=zeros(freq_length,2);S30_S30_T=zeros(freq_length,2);
D_K_PSIelement=zeros(1,10);D_F_PSIelement=zeros(1,10);D_G_PSIelement=zeros(1,10);
H_K_PSIelement=zeros(1,10);H_F_PSIelement=zeros(1,10);H_G_PSIelement=zeros(1,10);

for Hz_sig=1:freq_length
    H_Hz_sig=Hz_sig;
    D_Hz_sig=Hz_sig;
    
    load(strcat('.\D_sig_PSI\',num2str(D_Hz_sig),'\S3_D_sig_PSI_S1_95.mat'));
    load(strcat('.\D_sig_PSI\',num2str(D_Hz_sig),'\S3_D_sig_PSI_S3_95.mat'));
    load(strcat('.\H_sig_PSI\',num2str(H_Hz_sig),'\S3_H_sig_PSI_S1_95.mat'));
    load(strcat('.\H_sig_PSI\',num2str(H_Hz_sig),'\S3_H_sig_PSI_S3_95.mat'));
    
    
    time_length=100;
    plot_b=1:time_length;
    %%  For Depression group
    D_F_PSIsubject_mean=zeros(10,time_length);
    D_F_PSIsubject_all=zeros(10,time_length);
    D_G_PSIsubject_mean=zeros(10,time_length);
    D_G_PSIsubject_all=zeros(10,time_length);
    D_F=zeros(freq_length,time_length);
    D_G=zeros(freq_length,time_length);
    D_K=zeros(freq_length,time_length);
    for a=1:10
        F_cluster_D=[];G_cluster_D=[];
        F_cluster_D=S3_D_sig_PSI_S1{a};
        
        D_size=size(F_cluster_D);
        D_F_PSIsubject_mean(a,:)=mean(F_cluster_D(:,1:time_length)); %4*H_size/5
        D_F_PSIsubject_all(a,:)=D_F_PSIsubject_mean(a,:)*D_size(1);
        
        G_cluster_D=S3_D_sig_PSI_S3{a};
        D_G_PSIsubject_mean(a,:)=mean(G_cluster_D(:,1:time_length));
        D_G_PSIsubject_all(a,:)=D_G_PSIsubject_mean(a,:)*D_size(1);
    end
    D_F(Hz_sig,:)=mean(D_F_PSIsubject_mean);D_G(Hz_sig,:)=mean(D_G_PSIsubject_mean);D_K(Hz_sig,:)=D_F(Hz_sig,:)-D_G(Hz_sig,:);
    D_F(Hz_sig,:)=mean(D_F_PSIsubject_mean);D_G(Hz_sig,:)=mean(D_G_PSIsubject_mean);D_K(Hz_sig,:)=D_F(Hz_sig,:)-D_G(Hz_sig,:);

    %%  For Healthy group
    H_F_PSIsubject_mean=zeros(10,time_length);
    H_F_PSIsubject_all=zeros(10,time_length);
    H_G_PSIsubject_mean=zeros(10,time_length);
    H_G_PSIsubject_all=zeros(10,time_length);
    H_F=zeros(freq_length,time_length);
    H_G=zeros(freq_length,time_length);
    H_K=zeros(freq_length,time_length);
    for a=1:10
        F_cluster_H=[];G_cluster_H=[];
        F_cluster_H=S3_H_sig_PSI_S1{a};
        
        H_size=size(F_cluster_H);
        H_F_PSIsubject_mean(a,:)=mean(F_cluster_H(:,1:time_length));
        H_F_PSIsubject_all(a,:)=H_F_PSIsubject_mean(a,:)*H_size(1);
        
        G_cluster_H=S3_H_sig_PSI_S3{a};
        H_G_PSIsubject_mean(a,:)=mean(G_cluster_H(:,1:time_length));
        H_G_PSIsubject_all(a,:)=H_G_PSIsubject_mean(a,:)*H_size(1);
    end
    H_F(Hz_sig,:)=mean(H_F_PSIsubject_mean);H_G(Hz_sig,:)=mean(H_G_PSIsubject_mean);H_K(Hz_sig,:)=H_F(Hz_sig,:)-H_G(Hz_sig,:);
    H_F(Hz_sig,:)=mean(H_F_PSIsubject_mean);H_G(Hz_sig,:)=mean(H_G_PSIsubject_mean);H_K(Hz_sig,:)=H_F(Hz_sig,:)-H_G(Hz_sig,:);

   for aa=1:subject_num
        if select==1
            D_K_PSIelement(aa)=mean(D_F_PSIsubject_mean(aa,:)-D_G_PSIsubject_mean(aa,:));
            H_K_PSIelement(aa)=mean(H_F_PSIsubject_mean(aa,:)-H_G_PSIsubject_mean(aa,:));
        else
            D_K_PSIelement(aa)=mean((D_F_PSIsubject_mean(aa,:)-D_G_PSIsubject_mean(aa,:)))*D_size(1);
            H_K_PSIelement(aa)=mean((H_F_PSIsubject_mean(aa,:)-H_G_PSIsubject_mean(aa,:)))*H_size(1);
        end
    end
    [h,p,ci,stats]=ttest2(-D_K_PSIelement,-H_K_PSIelement,0.05,0);
    S30_S10_T(Hz_sig,:)=[p,stats.tstat];

    
    for aa=1:subject_num
        if select==1
            D_F_PSIelement(aa)=mean(D_F_PSIsubject_mean(aa,:));
            H_F_PSIelement(aa)=mean(H_F_PSIsubject_mean(aa,:));
        else
            D_F_PSIelement(aa)=mean(D_F_PSIsubject_mean(aa,:)*D_size(1));
            H_F_PSIelement(aa)=mean(H_F_PSIsubject_mean(aa,:)*H_size(1));
        end
    end
    [h,p,ci,stats]=ttest2(D_F_PSIelement,H_F_PSIelement,0.05,0);
    S10_S10_T(Hz_sig,:)=[p,stats.tstat];


    for aa=1:subject_num
        if select==1
            D_G_PSIelement(aa)=mean(D_G_PSIsubject_mean(aa,:));
            H_G_PSIelement(aa)=mean(H_G_PSIsubject_mean(aa,:));
        else
            D_G_PSIelement(aa)=mean(D_G_PSIsubject_mean(aa,:)*D_size(1));
            H_G_PSIelement(aa)=mean(H_G_PSIsubject_mean(aa,:)*H_size(1));
        end
    end
    [h,p,ci,stats]=ttest2(D_G_PSIelement,H_G_PSIelement,0.05,0);
    S30_S30_T(Hz_sig,:)=[p,stats.tstat];
end



if select==1
    save S30_S10_T_Allmean S30_S10_T
    figure;
    bar(b(1:25),(S30_S10_T(1:25,2)));grid minor;title('�����ֵˮƽS30-S10');
else
    save S30_S10_T_AllsigPairs S30_S10_T
    figure;
    bar(b(1:25),(S30_S10_T(1:25,2)));grid minor;title('����ˮƽ�����������Ķ���S30-S10');
end

