
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the functin of this script��
%           plot_cluster_RESULT.m
%           By on-line clustering method, we can draw the convergent brain
%           networks.
% kangkangsome@gmail.com
% Kang Cheng, 2019/07/18
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% close all;
clear all;
clc;
load('EEG_chanlocs.mat')
load('EEG_chaninfo.mat')
link_H=[];
% load('link_all.mat');
% link_H=link_all;
load('link_H.mat');
load('Hz_sig.mat');
load('select_mode.mat');
global Pair_length cc Ua_H

subject_num=16;
 %%     ���϶����Ա�ͼ            
% alpha_rad1=zeros(subject_num,length(link_H),100);
num1=[];
num2=[];

alpha_rad_all=zeros(length(link_H),subject_num*100);
for pair_i=1:length(link_H)
    alpha_rad1_element=[];
    num1=link_H(1,pair_i);
    num2=link_H(2,pair_i);
    for subject=1:subject_num
%% ---------------------------------------------------------------------
    alpha_rad1=[];
        
        % S10 �� �ǰд̼�
        if select_mode==1
        %  ����������
            load_file_S30=strcat('M:\Healthy_NabckParadigmPSI����(H)\',num2str(subject),'\1\S30\cohangle\',num2str(num1),'.mat');
            load(load_file_S30);
            alpha_rad1=cell_S30_cohangle{1};
            alpha_rad1_element=[alpha_rad1_element alpha_rad1(Hz_sig,51:150)];
        else if select_mode==0
        % ���㽡����
            load_file_S30=strcat('M:\Healthy_NabckParadigmPSI����(H)\',num2str(subject),'\1\S30\cohangle\',num2str(num1),'.mat');
            load(load_file_S30);
            alpha_rad1=cell_S30_cohangle{1};
            alpha_rad1_element=[alpha_rad1_element alpha_rad1(Hz_sig,51:150)];           
            end
        end
    end
    
    phase_data=reshape(alpha_rad1_element,1,length(alpha_rad1_element));
    [r d d_du Ua Ua_du Z]=Rayleigh_test(phase_data);
    
    R(1,pair_i)=r; R(2,pair_i)=num1; R(3,pair_i)=num2;
    D(1,pair_i)=d;
    Z_all(1,pair_i)=Z;
    Ua_H(1,pair_i)=Ua_du;  Ua_H(2,pair_i)=d_du; Ua_H(3,pair_i)=num1; Ua_H(4,pair_i)=num2;
    
    alpha_rad_all(pair_i,:)=phase_data;
end
[r d d_du Ua Ua_du Z]=Rayleigh_test( Ua_H(1,:));

% ��10�����Ե���λ�����һ������
% alpha_rad_all=zeros(length(link_H),1000);
% Ua_H=zeros(2,length(link_H));
% for pairs_i=1:length(link_H)
%     alpha_rad1_element=[];
%     for subject=1:subject_num
%         alpha_rad1_element=[alpha_rad1_element alpha_rad1(subject,pairs_i,:)];
%     end
%     phase_data=reshape(alpha_rad1_element,1,1000);
%     [Ua_du d_du]=Rayleigh_test(phase_data);
%     Ua_H(1,pairs_i)=Ua_du;
%     Ua_H(2,pairs_i)=d_du;
%     alpha_rad_all(pairs_i,:)=phase_data;
% end

colorbar_limit=360
% link = Ua_H(:,1:30); % Pair_length=length(link(1,:));
Pair_length=length(Ua_H(1,:));

for aa=1:Pair_length
    cc(aa)=abs(floor(64*Ua_H(1,aa)/colorbar_limit));
    if cc(aa)<=0
        cc(aa)=1;
    else if cc(aa)>=65
            cc(aa)=64;
        end
    end
end
figure;
linkplot([],EEG_chanlocs, Ua_H, 'style', 'blank',  'electrodes', 'labelpoint', 'chaninfo', EEG_chaninfo);
        caxis([0,colorbar_limit]);
        colorbar;%��ʾ��ɫ��

figure;
circ_plot(Ua_H(1,:)','hist',[],60,true,true,'linewidth',2,'color','r');
% save Ua_D Ua_D
% save alpha_rad_all alpha_rad_all
% 
% load('Ua_D.mat');
% clear Ua
% load('Ua_H.mat');
% B=Ua_H;

%% ---------------------------------------------------------------------
% [U2]=Watson_U2_test(A,B)

% clc
% phase_data=[66 75 86 88 88 93 97 101 118  130];
% 
% [Ua_du]=Rayleigh_test(phase_data)

